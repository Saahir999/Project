package com.example.hackathon

data class Rvhold( var quantity: Int )
