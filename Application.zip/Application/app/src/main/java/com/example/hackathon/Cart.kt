package com.example.hackathon

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.cart.*

class Cart: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cart)

        var todolist = mutableListOf(Rvhold(0),Rvhold(1),Rvhold(0),Rvhold(100),Rvhold(1))

        val adapter = ToDoAdapter(todolist)
        rvcart.adapter = adapter
        rvcart.layoutManager = LinearLayoutManager(this)
    }
}